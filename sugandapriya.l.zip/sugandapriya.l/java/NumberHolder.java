public class NumberHolder {

    public int anInt;
    public float anFloat;

    // static void execute()
    public static void main(String[] args) {

        // NumberHolder number1 = new NumberHolder()
        // number1.anInt = 45
        NumberHolder number1 = new NumberHolder();
        number1.anInt = 45;

        // Console console = getConsole()
        // Console console = getConsole()
        System.out.println(number1.anInt);

        // NumberHolder number2 = new NumberHolder()
        // number1.anFloat = 2.3f
        NumberHolder number2 = new NumberHolder();
        number2.anFloat = 2.3f;

        // Console console = getConsole()
        // console.print(number2.anInt)
        System.out.println(number2.anFloat);
    }
}
