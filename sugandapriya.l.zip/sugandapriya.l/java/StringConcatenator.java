public class StringConcatenator {

    // static void execute(){
    public static void main(String[] args) {

        // String hi = "HI,";
        // String mom = "mom";
        String hi = "HI,";
        String mom = "mom";

        // String result = hi + mom
        // console.print(result)
        String joinedString = hi + mom;
        System.out.println(joinedString);

        // String hi = concat(hi,mom)
        // console.print(hi)
        hi = hi.concat(mom);
        System.out.println(hi);
    }
}
