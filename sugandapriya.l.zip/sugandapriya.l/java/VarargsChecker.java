public class VarargsChecker {

    static void check(String str, int... number) {
        System.out.println("String value is :" + str);
        System.out.println("Number of arguments :" + number.length);

        for (int result : number)
            System.out.println("" + result);
        }

    public static void main(String[] args) {

        check("Result one", 45, 58, 98);
        check("Result two", 45);
        check("Result three");
    }
}
