import java.util.Arrays;

public class CitySorter {

    public static void main(String[] args) {

        String[] city = { "Madurai",
                          "Thanjavur",
                          "TRICHY",
                          "Karur",
                          "Erode",
                          "trichy",
                          "Salem"
                        };

    for (int i = 0; i < city.length; i++) {
        Arrays.sort(city);
        System.out.println(city[i]);
        System.out.println();
    }

    for (int i = 0; i < city.length; i++) {
        if (i % 2 == 0) {
            System.out.println(city[i].toUpperCase());
        }
    }
    }
}
