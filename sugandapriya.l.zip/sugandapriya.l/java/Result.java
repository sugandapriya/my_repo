public class Result {

    public static void main(String[] args) {

        String original = "software";
        int index = original.indexOf('a');
        StringBuilder result = new StringBuilder("hai");

        result.setCharAt(0, original.charAt(0));
        result.setCharAt(1, original.charAt(original.length()-3));
        result.insert(3, original.charAt(4));
        result.insert(3, original.substring(index, index + 3));
        result.append(original.substring(1,4));

        System.out.println(result);
    }
}
