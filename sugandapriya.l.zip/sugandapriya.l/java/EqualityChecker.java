public class EqualityChecker {

    // static void execute()
    public static void main(String[] args) {

        // String name1 = new String("")
        // String name2 = new String("")
        String nameone = new String("priya");
        String nametwo = new String("priya");

        // Console console = getConsole()
        // console.print(name = name1 == name2)
        System.out.println(nameone == nametwo);

        // Console console = getConsole()
        // console.print(name = name1.equals(name2))
        System.out.println(nameone.equals(nametwo));
    }
}
