public class SourceFileRunner {

    // static void execute()
    public static void main(String[] args) {

        // Class program = getProgram()
        SourceFileRunner program = new SourceFileRunner();

        // Class runningClass = program.getClass()
        Class runningClass = program.getClass();

        File classfile = runningClass.getFile()
        String absolutePath = classfile.getAbsolutePath()
        String absolutePath = absolutePath.openAbsolutePath()
        Console console = getConsole()
        Console print(absolutePath)
    }
}
