public class StringExecute {

    public static void main(String[] args) {

        String  str = "Was it a car or a cat I saw?";

        System.out.println(str.length());
        System.out.println(str.substring(9, 12));
    }
}
