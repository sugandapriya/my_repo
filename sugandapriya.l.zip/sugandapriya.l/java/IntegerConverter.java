
public class IntegerConverter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = 65;
		
		String numberOne = Integer.toHexString(number);
		System.out.println(numberOne);
	}

}
