public class ValueHolder {

    public static void main(String[] args) {

        Object objectOne = 100 / 24;
        System.out.println(objectOne.getClass().getTypeName());

        Object objectTwo = 'z' / 2;
        System.out.println(objectTwo.getClass().getTypeName());

        Object objectThree = 10.5 / 0.5;
        System.out.println(objectThree.getClass().getTypeName());

        Object objectFour = 10.5 / 0.5;
        System.out.println(objectFour.getClass().getTypeName());

        Object objectFive = 10.5 / 0.5;
        System.out.println(objectFive.getClass().getTypeName());
    }
}
