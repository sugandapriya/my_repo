public class ComputeResult {

    public static void main(String[] args) {

        StringBuilder sb = new StringBuilder("Able was I ere I saw Elba");
        System.out.println(sb.capacity());
    }
}
