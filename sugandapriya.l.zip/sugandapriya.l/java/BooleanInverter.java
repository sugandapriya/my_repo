public class BooleanInverter {

    // static void execute()
    public static void main(String[] args) {

        // boolean variable = value
        boolean variable = true;

        // variable = !variable
        variable = !variable;

        // console.print(variable)
        System.out.println("value is:" + variable);
    }
}
