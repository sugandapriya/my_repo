public class Rectangle {

    int area(int width, int height) {

        int c = width * height;
        return c;
    }

    public static void main(String[] args) {

        Rectangle myRect = new Rectangle();
        System.out.println("myRect area is" + myRect.area(40,50));
    }
}
