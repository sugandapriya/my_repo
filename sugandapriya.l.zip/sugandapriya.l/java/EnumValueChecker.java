public class EnumValueChecker {

    // enum Var1 = {  }
    public enum Fruit { APPLE,
                        ORANGE,
                        PEAR
    }

    // static void execute()
    public static void main(String[] args) {

        // Var1 var1 = assign constant
        Fruit fruitOne = Fruit.PEAR;
        Fruit fruitTwo = Fruit.APPLE;

        // compare enum variables with ==
        if (fruitOne == fruitTwo) {

            // print(data)
            System.out.println("true");
        }
        System.out.println("false");

        // compare enum variables with .equals
        if (fruitOne.equals(fruitTwo)) {

            // print(data)
            System.out.println("true");
        }
        System.out.println("false");
    }
}
