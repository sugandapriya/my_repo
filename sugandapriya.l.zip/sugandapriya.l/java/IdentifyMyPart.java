public class IdentifyMyPart {

    static int x;
    static int y;

    public static void main(String[] args) {

        IdentifyMyPart a = new IdentifyMyPart();
        IdentifyMyPart b = new IdentifyMyPart();

        a.x = 5; 
        b.x = 6;
        a.y = 1;
        b.y = 2;

        System.out.println("a.x = " + a.x);
        System.out.println("b.x = " + b.x);
        System.out.println("a.y = " + a.y);
        System.out.println("b.y = " + b.y);

        System.out.println("IdentifyMyPart.x = " + IdentifyMyPart.x);
        System.out.println("IdentifyMyPart.y = " + IdentifyMyPart.y);
    }
}
