UPDATE edu_semester_fee AS semf
		(SELECT stud.id, stud.roll_number, stud.`name`, semf.paid_status
		FROM edu_student AS stud
		INNER JOIN edu_semester_fee AS semf ON semf.stud_id=stud.id)
		SET semf.paid_status='paid' WHERE stud.roll_number='ssne1056';
		