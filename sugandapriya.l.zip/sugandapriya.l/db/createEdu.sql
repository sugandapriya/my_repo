CREATE TABLE edu_university
								(univ_code  CHAR(4) PRIMARY KEY 
								, university_name VARCHAR(100) NOT NULL
								);
								
CREATE TABLE edu_college
								(id INT PRIMARY KEY AUTO_INCREMENT
								, `code` CHAR(4) NOT NULL
								, `name` VARCHAR(100) NOT NULL
								, city VARCHAR(50) NOT NULL
								, state VARCHAR(50) NOT NULL
								, year_opened YEAR(4) NOT NULL
								, univ_code CHAR(4)
								, KEY fk_univ_code(univ_code)
								, CONSTRAINT fk_edu_college FOREIGN KEY (univ_code) 
								 REFERENCES edu_university(univ_code)
								 );						
								 
CREATE TABLE edu_department
									(dept_code CHAR(4) PRIMARY KEY
									, univ_code CHAR(4)
									, KEY fk_univ_code(univ_code)
									, CONSTRAINT fk_edu_department FOREIGN KEY (univ_code)
									  REFERENCES edu_university(univ_code)  
									, dept_name VARCHAR(50) NOT NULL
									);
								 		
CREATE TABLE edu_designation								
									(id INT PRIMARY KEY AUTO_INCREMENT
									, `name` VARCHAR(30) NOT NULL
									, rank CHAR(1) NOT NULL
									);	
																
																
CREATE TABLE edu_college_department
												(cdept_id INT PRIMARY KEY AUTO_INCREMENT
												, udept_code CHAR(4)
												, KEY fk_udept_code(udept_code)
												, CONSTRAINT fk_edu_college_department FOREIGN KEY (udept_code)
												 REFERENCES edu_department(dept_code)
											   , college_id INT
											   , KEY fk_college_id(college_id)
												, CONSTRAINT fk_edu_college_dep FOREIGN KEY (college_id)
												  REFERENCES edu_college(id)
												);		
												
CREATE TABLE edu_employee
									(id INT PRIMARY KEY AUTO_INCREMENT
									, `name` VARCHAR(100) NOT NULL
									, dob DATE NOT NULL
									, email VARCHAR(50) NOT NULL
									, phone BIGINT NOT NULL
									, college_id INT 
									, KEY fk_college_id(college_id)
									, CONSTRAINT fk_edu_emp FOREIGN KEY  (college_id)
									REFERENCES edu_college(id)
									, cdept_id INT
									, KEY fk_cdept_id	(cdept_id)
									, CONSTRAINT fk_edu_emplo FOREIGN KEY (cdept_id)
									REFERENCES edu_college_department(cdept_id)
									, desig_id INT 
									, KEY fk_desig_id(desig_id)
									, CONSTRAINT fk_edu_employee FOREIGN KEY (desig_id)
									REFERENCES edu_designation(id)
									);	
									
CREATE TABLE edu_syllabus
									(id INT PRIMARY KEY AUTO_INCREMENT
									, cdept_id INT
									, KEY fk_cdept_id(cdept_id)
									, CONSTRAINT fk_edu_syllabus FOREIGN KEY (cdept_id)	
									REFERENCES edu_college_department(cdept_id)
									, syllabus_code CHAR(4) NOT NULL
									, syllabus_name VARCHAR(100) NOT NULL	
									);	 						
									
CREATE TABLE edu_professor_syllabus
												( emp_id INT 
												, KEY fk_emp_id(emp_id)
												, CONSTRAINT fk_edu_professor_syllabus FOREIGN KEY (emp_id)	
												REFERENCES edu_employee(id)
												, syllabus_id INT 
												, KEY fk_syllabus_id(syllabus_id)
												, CONSTRAINT fk_edu_prof_syllabus FOREIGN KEY (syllabus_id)
												REFERENCES edu_syllabus(id)
												, semester TINYINT NOT NULL
												); 								
									
CREATE TABLE edu_student 
								( id INT PRIMARY KEY AUTO_INCREMENT
								, roll_number CHAR(8) NOT NULL
								, `name` VARCHAR(100) NOT NULL
								, dob DATE NOT NULL
								, gender CHAR(1) NOT NULL
								, email VARCHAR(50) NOT NULL
								, phone BIGINT NOT NULL
								, address VARCHAR(200) NOT NULL
								, academic_year YEAR(4) NOT NULL
								,cdept_id INT
								, KEY fk_cdept_id (cdept_id)
								, CONSTRAINT fk_edu_stu FOREIGN KEY (cdept_id)
								REFERENCES edu_college_department(cdept_id)
								,college_id INT 
								, KEY fk_college_id(college_id)
								, CONSTRAINT fk_edu_student FOREIGN KEY (college_id)
								REFERENCES edu_college(id)
								);	
								
CREATE TABLE edu_semester_fee
										(cdept_id INT
										, KEY fk_cdept_id(cdept_id)
										, CONSTRAINT fk_edu_semester_fee FOREIGN KEY (cdept_id)
										REFERENCES edu_college_department(cdept_id)
										, stud_id INT 
										, KEY fk_stud_id(stud_id)
										,CONSTRAINT fk_edu_semester FOREIGN KEY (stud_id)
										REFERENCES edu_student(id)
										, semester TINYINT NOT NULL
										, amount DOUBLE(18,2) NULL
										, paid_year YEAR(4) NULL
										, paid_status VARCHAR(10) NOT NULL
										);
										

CREATE TABLE edu_semester_result
											( stud_id INT 
											, CONSTRAINT fk_edu_semester_res FOREIGN KEY(stud_id)
											REFERENCES edu_student(id)
											, syllabus_id INT 
											, CONSTRAINT fk_edu_semester_result FOREIGN KEY(syllabus_id)
											REFERENCES edu_syllabus(id)
											, semester TINYINT NOT NULL
											, grade VARCHAR(2) NOT NULL
											, credits FLOAT NOT NULL
											,result_date DATE NOT NULL
											); 
											
																					
																																									 		