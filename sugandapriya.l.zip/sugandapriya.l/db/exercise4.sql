SELECT emp.id, emp.`name`, emp.dob, emp.email, emp.email, emp.phone, emp.college_id, 
			emp.cdept_id, emp.desig_id
			FROM edu_employee AS emp
			INNER JOIN edu_college AS col ON col.id=emp.college_id
			INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
			INNER JOIN edu_college_department AS cdept ON cdept.college_id=col.id
			INNER JOIN edu_designation AS desig ON desig.id=emp.desig_id
		  ORDER BY desig.rank, col.`name` ASC;