SELECT stud.roll_number, stud.`name`, stud.gender, stud.dob, stud.email, stud.phone, stud.address, col.`name`, dept.dept_name 
		FROM edu_student AS stud 
		INNER JOIN edu_college AS col ON col.id=stud.college_id
		INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
		INNER JOIN edu_department AS dept ON dept.univ_code=univ.univ_code
		INNER JOIN edu_semester_fee AS semf ON semf.stud_id=stud.id
		WHERE univ.univ_code IN ("au00")
		AND semf.semester='8';