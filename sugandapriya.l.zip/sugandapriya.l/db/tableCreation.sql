CREATE TABLE holly_artists
								(id INT PRIMARY KEY AUTO_INCREMENT
								, `name` VARCHAR(20)
								, 	native VARCHAR(20)
								, dob INT
								, networth_in_$ INT
								);
								
								
INSERT INTO holly_artists VALUES(DEFAULT, 'will smith', 'us', 25-09-68, 250000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'jackie chan', 'china', 07-04-84, 350000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'emma stone', 'us', 06-11-88, 28000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'adele', 'england', 20-05-88, 135000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'selena gomez', 'us', 22-07-92, 50000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'scarlet johanson', 'us', 22-11-84, 100000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'leonardo di caprio', 'us', 11-11-74, 245000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'chris hemsworth', 'australia', 11-08-83, 60000000);
INSERT INTO holly_artists VALUES(DEFAULT, 'ellen degeneres', 'us', 26-01-58, 300000000);

CREATE TABLE occupation
								(id INT PRIMARY KEY AUTO_INCREMENT
								, occup_name VARCHAR(30)  
								, artist_id INT 
								);						
								

												
								
INSERT INTO occupation VALUES(DEFAULT, 'actor', 1);
INSERT INTO occupation VALUES(DEFAULT, 'director', 2);
INSERT INTO occupation VALUES(DEFAULT, 'producer', 3);
INSERT INTO occupation VALUES(DEFAULT, 'singer', 4);
INSERT INTO occupation VALUES(DEFAULT, 'speaker', 5);
INSERT INTO occupation VALUES(DEFAULT, 'comedian', 6);

CREATE TABLE movie
						( movie_id INT PRIMARY KEY AUTO_INCREMENT
						, movie_name VARCHAR(30)
						);
						
INSERT INTO trn_movie VALUES(DEFAULT, 'spider man');						
INSERT INTO trn_movie VALUES(DEFAULT, 'titanic');
INSERT INTO trn_movie VALUES(DEFAULT, 'rush hour');
INSERT INTO trn_movie VALUES(DEFAULT, 'reverent');
INSERT INTO trn_movie VALUES(DEFAULT, 'spider man');
INSERT INTO trn_movie VALUES(DEFAULT, 'pursuit of happyness');
INSERT INTO trn_movie VALUES(DEFAULT, 'la la land');

								

