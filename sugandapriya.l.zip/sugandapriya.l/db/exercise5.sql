SELECT univ.university_name ,col.`name`, semr.grade, semr.credits, semr.semester FROM edu_semester_result AS semr
		INNER JOIN edu_student AS stud ON stud.id=semr.stud_id
		INNER JOIN edu_college AS col ON col.id=stud.college_id
		INNER JOIN  edu_university AS univ ON univ.univ_code=col.univ_code
		ORDER BY semr.semester, col.`name`ASC LIMIT 10;