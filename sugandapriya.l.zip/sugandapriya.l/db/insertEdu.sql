SELECT univ_code, university_name FROM edu_university;
SELECT id, univ_code, `code`, `name`, city, state, year_opened FROM edu_college;
SELECT dept_code, univ_code, dept_name FROM edu_department;
SELECT id, `name`, rank FROM edu_designation;
SELECT cdept_id, udept_code, college_id FROM edu_college_department;
SELECT id, college_id, cdept_id, desig_id, `name`, dob, email, phone FROM edu_employee;
SELECT id, cdept_id, syllabus_code,  syllabus_name FROM edu_syllabus;
SELECT emp_id, syllabus_id, semester FROM edu_professor_syllabus;
SELECT id, college_id, cdept_id, roll_number, `name`, dob, gender, email, phone, address, academic_year FROM edu_student;
SELECT cdept_id, stud_id, semester, amount, paid_year, paid_status FROM edu_semester_fee;
SELECT stud_id, syllabus_id, semester, grade, credits, result_date FROM edu_semester_result;



INSERT INTO edu_university(univ_code, university_name) VALUES('au00', 'anna university');
INSERT INTO edu_university(univ_code, university_name) VALUES('pu00', 'periyar university');
INSERT INTO edu_university(univ_code, university_name) VALUES('bu00', 'bharathiyar university');


INSERT INTO edu_college(`code`, `name`, city, state, year_opened, univ_code) VALUES	 ('au05', 'dhirajlal gandhi college of technology', 'salem', 'tamilnadu', 2013, 'au00')
																											  , ('bu56', 'cms institute of management and technology', 'ernakulam', 'kerala', 2004, 'bu00')
																										     , ('pu09', 'mahendra college of engineering', 'salem', 'tamilnadu', 1998, 'pu00') 
																											  , ('bu07', 'nehru college of management', 'coimbatore', 'tamilnadu', 1996, 'bu00')																									
																											  , ('au45', 'ssn college of engineering', 'chennai', 'tamilnadu', 1994, 'au00');


INSERT INTO edu_department(dept_code, univ_code, dept_name) VALUES ('ecbu', 'bu00', 'electronics and communication engineering'),
																						 ('eebu', 'bu00', 'electrical and electronics engineering'),
																						 ('itau', 'au00', 'information technology'),
																						 ('ciau', 'au00', 'civil engineering'),
																						 ('mhpu', 'pu00', 'mechanical engineering'),
																						 ('cspu', 'pu00', 'civil engineering');
																						 
INSERT INTO edu_designation(`name`, rank) VALUES('hod', 'a'),
																('professor', 'b');
																	
																
																
INSERT INTO edu_college_department(udept_code, college_id) VALUES ('itau', 1),
																						('ciau', 1),
																				  		('ciau', 5),
																						('itau', 5),
																						('cspu', 3),
																						('mhpu', 3),
																						('ecbu', 2),
																					   ('eebu', 2),
																					   ('ecbu', 4),
																					   ('eebu', 4);
																					  
																					   
INSERT INTO edu_employee(`name`, dob, email, phone, college_id, cdept_id, desig_id) VALUES ('rena', '1992-04-29', 'rena@gmail.com', 7485125461, 1, 1, 2),
																														('sumathi', '1980-06-26', 'sm@gmail.com', 7459263815, 1, 2, 1),
																														('vanathi', '1982-09-12', 'va@gmail.com', 9854236715, 5, 3, 1),
																														('sridevi', '1985-08-17', 'sri@gmail.com', 8756314962, 5, 4, 2),
																														('santhosh', '1986-05-24', 'san@gmail.com', 9751236489, 3, 5, 2),
																														('prabakar', '1988-09-12', 'pb@gmail.com', 8631475296, 3, 6,1),
																														('vijay', '1980-10-19', 'vi@gmail.com', 8534796145, 2, 7, 2),
																														('vinoth', '1981-03-13', 'vin@gmail.com', 974562718, 2, 8, 1),
																														('bopathy', '1981-07-23', 'bop@gmail.com', 9745866718, 4, 9, 1),					
																														('nova', '1986-07-23', 'nop@gmail.com', 975666718, 4, 10, 2);
	
INSERT INTO edu_syllabus(cdept_id, syllabus_code, syllabus_name) VALUES (1, 'ita1', 'info tech'),
																								(1, 'ita2', 'computer basics'),
																								(2, 'cia1', 'structural basics'),
																								(2, 'cia2', 'quality management'),
																								(4, 'ita1', 'info tech'),
																								(4, 'ita2', 'computer basics'),
																								(3, 'cia1', 'structural basics'),
																								(3, 'cia2', 'quality management'),
																								(5, 'csp1', 'computer architecture'),
																								(5, 'csp2', 'computer network'),
																								(6, 'mhp1', 'mechanics'),
																								(6, 'mhp2', 'manufacture engineering'),
																								(7, 'ecb1', 'embedded systems'),
																								(7, 'ecb2', 'circuit theory'),
																								(8, 'eeb1', 'electrical instrumentation'),
																								(8, 'eeb2', 'electronic devices'),
																								(9, 'ecb1', 'embedded systems'),   
																								(9, 'ecb2', 'circuit theory'),
																								(10, 'ecb1', 'electrical instrumentation'),
																								(10, 'eeb2', 'electronic devices');
																								 
																								 
INSERT INTO edu_professor_syllabus(	emp_id, syllabus_id, semester) VALUES (1,	1, 1),
																								  (2, 4, 3),																						 
																							     (3, 7, 5),
																							     (4, 5, 6), 
																								  (5, 10, 3),
																								  (6, 12, 3),
																								  (7, 13, 4),
																								  (8, 15, 3),
																								  (9, 18, 8),
																								  (10, 19, 7);
																								 
INSERT INTO edu_student(college_id, cdept_id, roll_number, `name`, dob, gender, email, phone, address, academic_year) 
							VALUES (1, 1, 'dgct0011', 'saranya', '1996-10-24', 'f', 'sara@gmail.com', 8453691274, '2/3 mvs street,salem-6', '2018'),
																																								   	(1, 1, 'dgct0031', 'thilrus', '1996-11-24', 'f', 'ra@gmail.com', 8485369412, '3 msdstreet,salem-9', '2018'),
																																										(1, 1, 'dgct0021', 'subha', '1996-08-05', 'f', 'ara@gmail.com', 8534796215, 'p/3 nehru street,salem-7', '2018'),
																																										(1, 1, 'dgct0051', 'reena', '1996-04-09', 'f', 'saa@gmail.com', 8453694859, 'k/3 vvs street,salem-4', '2018'),
																																										(1, 1, 'dgct0018', 'priya', '1996-08-29', 'f', 'sar@gmail.com', 8456317895, '3 mss street,salem-5', '2018'),																							 
																																										(2, 8, 'cmst0011', 'agrasha', '1996-08-09', 'f', 'agra@gmail.com', 9953691274, '23 gadhi street,salem-6', '2018'),
																																										(2, 8, 'cmst0002', 'shivani', '1996-09-19', 'f', 'shiv@gmail.com', 7593148269, '53,beach road, chennai-28', '2018'),
																																										(2, 8, 'cmst0019', 'ayswariya', '1996-08-08', 'f','ays@gmail.com', 9832145678, '65, main road, trichy-7','2018'),
																																										(2, 8, 'cmst0411', 'madhu', '1997-05-19', 'f', 'madhu@gmail.com', 8595123654, '88, cross road street, chennai-9', '2018'),
																																										(2, 8, 'cmst0008', 'suchi', '1996-09-06', 'f', 'suc@gmail.com', 7894561235, '67, main cross, coimbatore-6', '2018'),
																																										(3, 6, 'mhce0012', 'kartik', '1996-09-17', 'm', 'kar@gmail.com', 1237894562, '12,third cross street,salem-32', '2018'),
																																										(3, 6, 'mhce0512', 'venkat', '1997-04-09', 'm', 'ven@gmail.com', 7412589632, '87, sunny street,trichy-12', '2018'),														
																																										(3, 6, 'mhce0902', 'ram', '1996-05-05', 'm', 'ra@gmail.com', 8759623641, '54, third  stret,salem-19', '2018'),
																																										(3, 6, 'mhce2012', 'naveen', '1996-06-18', 'm', 'nav@gmail.com', 9845612375, '123, bharathi street,salem-09', '2018'),
																																										(3, 6, 'mhce6012', 'hari', '1997-05-29', 'm', 'hari@gmail.com', 7589632145, '5,anna street,coimbatore-08', '2018'),
																																										(4, 10, 'ncom0056', 'monica', '1996-07-07', 'f', 'mon@gmail.com', 7592364185, '67, secg street, salem-08', '2018'),
																																										(4, 10, 'ncom0056', 'nivetha', '1996-12-23', 'f', 'niv@gmail.com', 742589632, '78,hgyf road, trichy-06', '2018'),
																																										(4, 10, 'ncom0056', 'ishwarya', '1997-04-15', 'f', 'ish@gmail.com', 8954796321, 'post road street,coimbatore-9', '2018'),
					  																																					(4, 10, 'ncom0056', 'iniya', '1996-09-24', 'f', 'ini@gmail.com', 9874561235, 'gfr road, trichy-87', '2018'),
					 																																					(4, 10, 'ncom0056', 'nilaa', '1997-05-12', 'f', 'nil@gmail.com', 8745612395, '45,fifth cross road, chennai-8', '2018'),
																																										(5, 3, 'ssne0056', 'swathi', '1996-05-12', 'f', 'swa@gmail.com', 8954127963, 'gyk road,trichy-5', '2018'),
																					   																				(5, 3, 'ssne1056', 'keerthi', '1997-03-14', 'f', 'keer@gmail.com', 892568413, 'wer main street, salem-8', '2018'),
																					   																				(5, 3, 'ssne0256', 'monisha', '1996-12-12', 'f', 'moni@gmail.com', 7569844899, 'piuy cross road street,chennai-22', '2018'),
																																			 							(5, 3, 'ssne0666', 'nandhini', '1996-05-16','f', 'nan@gmail.com', 789456852, 'fdhj main road, chennai-9', '2018'),
																						 																				(5, 3, 'ssne0156', 'janani', '1997-11-06', 'f', 'jan@gmail.com', 9874895687, 'fryid third cross street ,salem7', '2018');


																				 																				
																						 																				
INSERT INTO edu_semester_fee (cdept_id, stud_id, semester, amount, paid_year, paid_status) 
																														VALUES (	1, 1, 8, 10000, '2018', 'paid'),	
																																 (	1, 4, 7, 10000, '2018', 'paid'),	
																																 (	1, 5, 8, NULL, '2018', 'unpaid'),	
																																 (	6, 11,5, 10000, '2018', 'paid'),	
																																 (	6, 12, 4, NULL, '2018', 'unpaid'),	
																																 (	6, 13, 2, 10000, '2018', 'paid'),	
																																 (	3, 14, 8, 10000, '2018', 'paid'),	
																																 (	10, 16, 7, 10000, '2018', 'paid'),	
																																 (	10, 18, 5, NULL, '2018', 'unpaid'),	
																																 (	10, 19, 1, 10000, '2018', 'paid'),	
																																 (	8, 6, 7, 10000, '2018', 'paid'),	
																																 (	8, 7, 8, NULL, '2018', 'unpaid'),	
																																 (	1, 2, 2, 10000, '2018', 'paid'),	
																																 (	1, 3, 3, 10000, '2018', 'paid'),	
																																 (	8, 6, 5, NULL, '2018', 'unpaid'),	
																																 (	8, 7, 8, 10000, '2018', 'paid'),	
																																 (	3, 22, 5, NULL, '2018', 'unpaid'),	
																																 (	3, 24, 7, 10000, '2018', 'paid'),	
																																 (	3, 25, 8, 10000, '2018', 'paid');
																																 
INSERT INTO edu_semester_result (stud_id, syllabus_id, semester, grade, credits, result_date)
																															VALUES (1, 1, 8, 'a', 9, '2018-05-05'),
																																	 (2, 1, 5, 's', 10, '2018-05-15'),
																																	 (3, 2, 6, 'b', 8, '2018-05-25'),
																																	 (4, 3, 2, 'd', 6, '2018-05-06'),
																																	 (5, 5, 3, 'a', 9, '2018-05-07'),
																																	 (6, 16, 8, 'e', 5, '2018-05-05'),
																																	 (7, 17, 8, 's',10, '2018-05-05'),
																																	 (8, 18, 5, 'a', 9, '2018-05-15'),
																																	 (9, 19,1, 'd', 7, '2018-05-20'),
																																	 (10, 20, 5, 'b', 8, '2018-05-15'),
																																	 (11, 9, 7, 'a', 9, '2018-05-03'),
																																	 (12, 10, 4, 's', 10, '2018-05-03'),
																																	 (13, 11, 5, 'e', 5, '2018-05-15'),
																																	 (14, 12, 6, 'a', 9, '2018-05-06'),
																																	 (25, 1, 4, 'a', 9, '2018-05-03'),
																																	 (21, 2, 5, 'a', 9, '2018-05-15'),
																																	 (22, 4, 6, 'a', 9, '2018-05-06'),
																																	 (23, 3, 8, 'a', 9, '2018-05-05');																																 
																																			
																																																																																 																				