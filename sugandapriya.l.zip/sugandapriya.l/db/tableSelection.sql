SELECT * FROM trn_hollywood_artists;

SELECT id, occup_name FROM trn_occupation;

SELECT movie_id, movie_name FROM trn_movie;

SELECT * FROM trn_hollywood_artists as h RIGHT JOIN trn_movie AS m ON h.id1=m.movie_id; 

SELECT * FROM trn_hollywood_artists AS h LEFT JOIN trn_occupation AS o ON h.artist_id=o.id;
			
SELECT MAX(networth_in_$) FROM trn_hollywood_artists;

SELECT id, `name`, born, networth_in_$, id1 FROM trn_hollywood_artists ORDER BY id DESC;

SELECT * FROM hollywood;

SELECT * FROM tr_hollywood;											

SELECT * FROM tr_holly;											

SELECT `name`, id FROM trn_hollywood_artists GROUP BY `name` HAVING MAX(id)>=3;

SELECT `name`, id FROM trn_hollywood_artists WHERE `name` LIKE "%i%";

SELECT `name`, id FROM trn_hollywood_artists WHERE `name` ESCAPE '%i%';

SELECT id,`name` FROM trn_hollywood_artists  UNION DISTINCT SELECT movie_id, movie_name FROM trn_movie;

SELECT `name`, id, artist_id FROM trn_hollywood_artists WHERE (artist_id=1 OR id<4);
		
		
SELECT COUNT(id), `name` FROM trn_hollywood_artists GROUP BY `name` HAVING COUNT(id)>5;	
SELECT COUNT(DISTINCT artist_id) FROM trn_hollywood_artists;	


SELECT * FROM trn_hollywood_artists WHERE artist_id = (SELECT id FROM trn_occupation WHERE occup_name='actor');