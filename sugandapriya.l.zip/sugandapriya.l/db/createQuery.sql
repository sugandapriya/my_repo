CREATE TABLE edu_university
									(univ_code CHAR(4) PRIMARY KEY AUTO_INCREMENT
									, university_name VARCHAR(100) NOT NULL
									);