SELECT univ.university_name, col.`name`, semf.semester, 
		semf.amount, semf.paid_year, semf.paid_status
		FROM edu_semester_fee AS semf 
		INNER JOIN edu_student AS stud ON stud.id=semf.stud_id
		INNER JOIN edu_college AS col ON col.id=stud.college_id
		INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
		WHERE semf.semester='5' OR univ.university_name ='au00';
		
		
		
SELECT univ.university_name, col.`name`, semf.semester, 
		semf.amount, semf.paid_year, semf.paid_status, univ.university_name
		FROM edu_semester_fee AS semf 
		INNER JOIN edu_student AS stud ON stud.id=semf.stud_id
		INNER JOIN edu_college AS col ON col.id=stud.college_id
		INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
		WHERE semf.paid_status IN ('paid') ;