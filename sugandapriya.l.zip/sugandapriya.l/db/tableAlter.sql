ALTER TABLE trn_hollywood_artists ADD artist_id INT;
 
ALTER TABLE trn_hollywood_artists DROP FOREIGN KEY c_name_fk;

ALTER TABLE trn_hollywood_artists DROP COLUMN identity;

SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE holly_artists CHANGE COLUMN `native` `born` VARCHAR(10);

ALTER TABLE trn_hollywood_artists ADD (art_id INT);

ALTER TABLE trn_hollywood_artists ADD (artist_id  INT, CONSTRAINT c_fk FOREIGN KEY (artist_id ) REFERENCES trn_occupation(id));

ALTER TABLE trn_hollywood_artists ADD (id1 INT, CONSTRAINT c_fk_m FOREIGN KEY (id1) REFERENCES trn_movie(movie_id));
