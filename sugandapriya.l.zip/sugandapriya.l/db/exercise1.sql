SELECT col.`code`, col.`name`, univ.university_name, col.city, col.state, col.year_opened, dept.dept_name, emp.`name` 
				FROM edu_college AS col
				INNER JOIN edu_college_department AS cdep ON cdep.college_id=col.id
				INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
			 	INNER JOIN edu_department AS dept ON dept.univ_code=univ.univ_code
				INNER JOIN edu_employee AS emp ON emp.college_id=col.id
				INNER JOIN edu_designation AS desig ON desig.id=emp.desig_id
				WHERE dept.dept_code  IN ('itau', 'cspu')
				AND desig.id =1; 
				
				
				