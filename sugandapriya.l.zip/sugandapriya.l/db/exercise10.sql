SELECT stud.id, stud.roll_number, stud.`name`, stud.dob, stud.gender
		, stud.email, stud.phone, stud.address, stud.academic_year
		, semr.semester, semr.credits, univ.univ_code, univ.university_name
		FROM edu_student AS stud 
		INNER JOIN edu_semester_result AS semr ON semr.stud_id=stud.id
		INNER JOIN edu_college AS col ON col.id=stud.college_id
		INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
		WHERE semr.credits>'8';
		

SELECT stud.id, stud.roll_number, stud.`name`, stud.dob, stud.gender
		, stud.email, stud.phone, stud.address, stud.academic_year
		, semr.semester, semr.credits, univ.univ_code, univ.university_name
		FROM edu_student AS stud 
		INNER JOIN edu_semester_result AS semr ON semr.stud_id=stud.id
		INNER JOIN edu_college AS col ON col.id=stud.college_id
		INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
		WHERE semr.credits>5;
		