UPDATE holly_artists SET born='hongkong' WHERE id='2';

RENAME TABLE hollywood_artists TO trn_hollywood_artists;

RENAME TABLE occupation TO trn_occupation; 

RENAME TABLE movie TO trn_movie;

CREATE VIEW hollywood AS SELECT `name`, born FROM trn_hollywood_artists;

CREATE VIEW tr_hollywood AS SELECT  `name`, born, networth_in_$, occup_name, movie_name
							 FROM trn_hollywood_artists AS h
							 CROSS JOIN trn_occupation AS o ON h.artist_id=o.id
							 CROSS JOIN trn_movie AS m ON h.id1=m.movie_id;		
							 
							 
							 