SELECT stud.roll_number, stud.`name`, stud.gender, stud.dob, stud.email, stud.phone, stud.address, col.`name`, dept.dept_name, emp.`name`
		FROM edu_student AS stud 
		INNER JOIN edu_college AS col ON col.id=stud.college_id
		INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
		INNER JOIN edu_college_department AS cdept ON cdept.college_id=col.id
		INNER JOIN edu_department AS dept ON dept.dept_code=cdept.udept_code
		INNER JOIN edu_employee AS emp ON col.id=emp.college_id
		INNER JOIN edu_designation AS desig ON emp.desig_id=desig.id
		WHERE univ.univ_code IN ("bu00")
		AND col.city IN ("coimbatore") AND desig.id='1';