SELECT desig.`name`, desig.rank, col.`name`, dept.dept_name, univ.university_name, univ.univ_code 
		FROM edu_designation AS desig 
		INNER JOIN edu_employee AS emp ON emp.desig_id=desig.id
		INNER JOIN edu_college AS col ON col.id=emp.college_id
		INNER JOIN edu_university AS univ ON univ.univ_code=col.univ_code
		INNER JOIN edu_department AS dept ON dept.univ_code=univ.univ_code